--
-- PostgreSQL database dump
--

\restrict p5lVd5ZCJYOxT7ziLUNKrNNXCEkq0zK7ubJxmKe3Ddz47q9k76gQJ6DzaeW9Zfg

-- Dumped from database version 15.18 (Debian 15.18-1.pgdg13+1)
-- Dumped by pg_dump version 15.18 (Debian 15.18-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: escrow_deposits_estado_enum; Type: TYPE; Schema: public; Owner: protask
--

CREATE TYPE public.escrow_deposits_estado_enum AS ENUM (
    'retenido',
    'liberado',
    'reembolsado'
);


ALTER TYPE public.escrow_deposits_estado_enum OWNER TO protask;

--
-- Name: kyc_verificaciones_status_enum; Type: TYPE; Schema: public; Owner: protask
--

CREATE TYPE public.kyc_verificaciones_status_enum AS ENUM (
    'pendiente',
    'aprobado',
    'rechazado'
);


ALTER TYPE public.kyc_verificaciones_status_enum OWNER TO protask;

--
-- Name: users_role_enum; Type: TYPE; Schema: public; Owner: protask
--

CREATE TYPE public.users_role_enum AS ENUM (
    'cliente',
    'freelancer',
    'administrador'
);


ALTER TYPE public.users_role_enum OWNER TO protask;

--
-- Name: users_status_enum; Type: TYPE; Schema: public; Owner: protask
--

CREATE TYPE public.users_status_enum AS ENUM (
    'activo',
    'inactivo',
    'suspendido',
    'pendiente_verificacion'
);


ALTER TYPE public.users_status_enum OWNER TO protask;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: escrow_deposits; Type: TABLE; Schema: public; Owner: protask
--

CREATE TABLE public.escrow_deposits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    monto numeric(10,2) NOT NULL,
    estado public.escrow_deposits_estado_enum DEFAULT 'retenido'::public.escrow_deposits_estado_enum NOT NULL,
    "liberadoEn" timestamp without time zone,
    "reembolsadoEn" timestamp without time zone,
    "depositadoEn" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "proposalId" uuid,
    "clienteId" uuid,
    "freelancerId" uuid
);


ALTER TABLE public.escrow_deposits OWNER TO protask;

--
-- Name: kyc_verificaciones; Type: TABLE; Schema: public; Owner: protask
--

CREATE TABLE public.kyc_verificaciones (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "userId" uuid NOT NULL,
    status public.kyc_verificaciones_status_enum DEFAULT 'pendiente'::public.kyc_verificaciones_status_enum NOT NULL,
    "dniFrentePath" character varying(500),
    "dniDorsoPath" character varying(500),
    "selfieConDniPath" character varying(500),
    "motivoRechazo" text,
    "revisadoPorId" character varying,
    "revisadoEn" timestamp without time zone,
    "enviadoEn" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.kyc_verificaciones OWNER TO protask;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: protask
--

CREATE TABLE public.projects (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    title character varying(100) NOT NULL,
    description text NOT NULL,
    category character varying NOT NULL,
    budget numeric(10,2) NOT NULL,
    deadline_days integer NOT NULL,
    status character varying DEFAULT 'open'::character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "clientId" uuid,
    "isCorporate" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.projects OWNER TO protask;

--
-- Name: proposals; Type: TABLE; Schema: public; Owner: protask
--

CREATE TABLE public.proposals (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "offeredPrice" numeric(10,2) NOT NULL,
    "estimatedDays" integer NOT NULL,
    description text NOT NULL,
    status character varying DEFAULT 'pending'::character varying NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "projectId" uuid,
    "freelancerId" uuid
);


ALTER TABLE public.proposals OWNER TO protask;

--
-- Name: users; Type: TABLE; Schema: public; Owner: protask
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    password character varying NOT NULL,
    role public.users_role_enum DEFAULT 'cliente'::public.users_role_enum NOT NULL,
    status public.users_status_enum DEFAULT 'pendiente_verificacion'::public.users_status_enum NOT NULL,
    phone character varying(20),
    bio character varying(500),
    "avatarUrl" character varying(255),
    location character varying(100),
    "hourlyRate" numeric(10,2),
    skills text,
    rating numeric(3,2) DEFAULT '0'::numeric NOT NULL,
    "totalReviews" integer DEFAULT 0 NOT NULL,
    "completedProjects" integer DEFAULT 0 NOT NULL,
    "isVerified" boolean DEFAULT false NOT NULL,
    "verifiedAt" timestamp without time zone,
    "lastLoginAt" timestamp without time zone,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "portfolioFiles" text
);


ALTER TABLE public.users OWNER TO protask;

--
-- Data for Name: escrow_deposits; Type: TABLE DATA; Schema: public; Owner: protask
--

COPY public.escrow_deposits (id, monto, estado, "liberadoEn", "reembolsadoEn", "depositadoEn", "updatedAt", "proposalId", "clienteId", "freelancerId") FROM stdin;
732d66b9-1a6f-4552-ba80-58e60566c071	1800.00	retenido	\N	\N	2026-05-24 02:00:34.660768	2026-05-24 02:00:34.660768	5014e373-cd17-4272-a6b5-62b020a2c1ae	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	5b81d723-3a98-4315-aed8-4cb2d63ac2c1
\.


--
-- Data for Name: kyc_verificaciones; Type: TABLE DATA; Schema: public; Owner: protask
--

COPY public.kyc_verificaciones (id, "userId", status, "dniFrentePath", "dniDorsoPath", "selfieConDniPath", "motivoRechazo", "revisadoPorId", "revisadoEn", "enviadoEn", "createdAt", "updatedAt") FROM stdin;
cf4a0367-59aa-4b92-87eb-0103bfbc101d	3d36bad7-5998-4d98-9717-82d3f3ca5985	aprobado	uploads/kyc/3d36bad7-5998-4d98-9717-82d3f3ca5985/dniFrente-1779338018214-494302944.jpg	uploads/kyc/3d36bad7-5998-4d98-9717-82d3f3ca5985/dniDorso-1779338018218-852892812.jpg	uploads/kyc/3d36bad7-5998-4d98-9717-82d3f3ca5985/selfieConDni-1779338018219-691791783.png	\N	ff995b9b-0d0a-4090-bba3-3017af290ac6	2026-05-21 00:51:13.94	2026-05-21 00:33:38.427	2026-05-21 04:33:38.458877	2026-05-21 04:51:13.978762
cfb735e7-abf2-4509-b0b8-0f5f82504866	5f3917fb-0753-41be-aa3e-e3eda8418990	aprobado	uploads/kyc/tmp/dniFrente-1779395731527-404838231.jpg	uploads/kyc/tmp/dniDorso-1779395731518-480607505.jpg	uploads/kyc/tmp/selfieConDni-1779395731528-283605257.jpg	\N	\N	2026-05-21 16:41:49.033	2026-05-21 16:35:31.57	2026-05-21 20:35:31.575111	2026-05-21 20:41:49.035838
68f2fb1f-1bd5-43d7-9107-8970414d1035	19a5686b-a527-4366-a2f7-9849fcb11f7c	aprobado	uploads/kyc/tmp/dniFrente-1779402825638-250349446.jpg	uploads/kyc/tmp/dniDorso-1779402825639-921326815.jpg	uploads/kyc/tmp/selfieConDni-1779402825639-162015857.jpg	\N	\N	2026-05-21 18:36:47.667	2026-05-21 18:33:45.679	2026-05-21 22:33:45.68207	2026-05-21 22:36:47.678223
444fb3fc-ffe1-405f-8392-b83a17723dda	5b81d723-3a98-4315-aed8-4cb2d63ac2c1	aprobado	uploads/kyc/5b81d723-3a98-4315-aed8-4cb2d63ac2c1/dniFrente-1779582033060-804621249.jpg	uploads/kyc/5b81d723-3a98-4315-aed8-4cb2d63ac2c1/dniDorso-1779582033065-728896055.jpg	uploads/kyc/5b81d723-3a98-4315-aed8-4cb2d63ac2c1/selfieConDni-1779582033080-948212567.jpg	\N	5242a885-1ba7-416b-8b4a-2a11667e45d3	2026-05-23 20:23:21.534	2026-05-23 20:20:33.438	2026-05-24 00:20:33.461965	2026-05-24 00:23:21.570566
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: protask
--

COPY public.projects (id, title, description, category, budget, deadline_days, status, "createdAt", "updatedAt", "clientId", "isCorporate") FROM stdin;
a771453b-61a8-4fa0-a763-b0809ef9c400	Mi primer proyecto	Necesito una app web	Desarrollo Web	500.00	15	open	2026-05-19 16:39:15.52076	2026-05-19 16:39:15.52076	\N	f
cd165940-6a52-45b1-b0eb-10679bd9bf18	Segundo testeo	Necesito una web	Desarrollo WeBBB	300.00	20	open	2026-05-19 17:30:03.050058	2026-05-19 17:30:03.050058	\N	f
9735f19b-55e2-4f1e-8922-6a76f3816f1b	Proyecto real	...	Desarrollo	500.00	15	open	2026-05-19 19:59:45.760658	2026-05-19 19:59:45.760658	\N	f
ef3bcd39-130c-418e-83f5-7c56cd6aae8f	Proyecto dos	...	Desarrollo de nuevo	500.00	15	open	2026-05-19 20:10:26.801738	2026-05-19 20:10:26.801738	96f123c0-285e-449b-be59-49c695dab4a7	f
61659598-4e05-41e2-b602-bb1b6f76bb8e	Tienda online	Necesito una tienda virtual con carrito de compras	Desarrollo Web	1000.00	25	open	2026-05-19 23:34:31.353076	2026-05-19 23:34:31.353076	\N	f
78be32f2-4e88-441d-abfc-a89f438c8d97	Tienda onlineeeeee	Necesito una tienda virtual con carrito de compraseeeeee	Desarrollo Webbbbbbbbbbbbbb	1000.00	25	open	2026-05-19 23:39:52.696228	2026-05-19 23:39:52.696228	\N	f
ea5139c0-e7b5-4f1c-b083-94db9d7de611	Tienda onlineeeeee44444444444	Necesito una tienda virtual con carrito de compraseeeeee3333333333	Desarrollo Webbbbbbbbbbbbbb2222222	1000.00	25	open	2026-05-19 23:42:58.55952	2026-05-19 23:42:58.55952	\N	f
c97dfdca-538d-4f63-bf47-4b5891a4c452	Tienda o4	Necesito una ti	Desarro	1000.00	25	open	2026-05-19 23:45:36.520643	2026-05-19 23:45:36.520643	\N	f
d53595ea-7974-4e4b-9e07-aa613d64f656	TiendQQQQQQQQQa o4	NeceQQQQQQQQsito una ti	DesaQQQQQQQQQrro	1000.00	25	open	2026-05-19 23:58:04.677953	2026-05-19 23:58:04.677953	fb42a0b8-f904-4123-b4c7-cb92266c9522	f
a5811238-8a18-43d9-b15d-fb8c810019b3	Proyecto para probar KYC	Este proyecto requiere freelancer verificado	Desarrollo Web	1000.00	20	open	2026-05-21 18:06:52.673272	2026-05-21 18:06:52.673272	ca80d7f7-43ab-48e1-8030-9cc49f1ba63e	f
787badac-c162-473a-b516-b2987e871381	Plataforma de gestión de inventario para tiendas	Necesitamos un sistema web para control de inventario, ventas y reportes. Debe tener panel de administración y acceso para múltiples usuarios.	Desarrollo Web	3500.00	60	open	2026-05-21 20:48:54.607078	2026-05-21 20:48:54.607078	60460136-1c2e-4041-bad4-933625da3ade	f
44fccee3-f321-4a7b-90b9-8f5631118ac3	App de gestión de inventario	Necesitamos...	Desarrollo Web	3000.00	45	open	2026-05-21 22:29:47.095341	2026-05-21 22:29:47.095341	462687d5-0742-4c7b-b69a-627074be1887	f
f8ad0de6-82f2-4a39-a9e8-06887d7a794e	App de inventario actualizada	Necesitamos3434...	Desarrollo Web	3500.00	4535	cancelled	2026-05-21 22:46:48.656102	2026-05-21 23:03:21.369446	462687d5-0742-4c7b-b69a-627074be1887	f
c3bc3b97-ebfd-4741-869c-09eaf168d7af	App de entregas a domicilio	Necesitamos una aplicación móvil y web para gestionar entregas en tiempo real	Desarrollo Móvil	4000.00	50	in_progress	2026-05-22 22:15:39.420629	2026-05-22 22:29:15.952454	2ee88ddf-1da7-48c1-8a7a-c33d0c6c8f4d	f
38e0bdee-6e5f-4135-9acb-f2163da39a4b	App de entregas	Necesito una app para repartidores	Desarrollo Móvil	2000.00	30	open	2026-05-23 22:15:54.773535	2026-05-23 22:15:54.773535	\N	f
3325c803-614b-474d-b6b7-f32702602254	AAAAApp de entregas	NAAecesito una app para repartidores	AAAADesarrollo Móvil	2000.00	30	open	2026-05-24 01:07:34.514474	2026-05-24 01:07:34.514474	\N	f
ab940f9d-425f-4c83-88eb-1543b0926ac2	AasdasdsadAAAAsadasdadasdsdpp de entregas	NAAsdadasdasdasdasdasdasdasdadsadasdecesito una app para repartidores	AAAADeasdsadasdasdsadsdasarrollo Móvil	2000.00	30	open	2026-05-24 01:12:40.883123	2026-05-24 01:12:40.883123	\N	f
2f7f2aee-501d-4c30-b923-136031649fa2	Proyecto desde nuevo cliente	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 01:14:59.050335	2026-05-24 01:14:59.050335	\N	f
c05cf8be-bada-45ed-bc27-e7687fcba93f	Proyecto DESDE NUEVO CLIENTE	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	in_progress	2026-05-24 01:22:01.264482	2026-05-24 01:25:44.450601	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
68e4cfc1-f134-45e5-b09d-32acd6d62062	PROYECTO 3 AAAAAH	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 01:55:20.495622	2026-05-24 01:55:20.495622	19a5686b-a527-4366-a2f7-9849fcb11f7c	f
d267cdf8-b859-494e-85d1-c163cc946368	PROYECTO 3 AAAAAH	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	in_progress	2026-05-24 01:57:20.935868	2026-05-24 02:00:27.303204	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
5d142024-1d8e-4de6-a6b5-247cf748d1f8	Proyecto 01 	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 03:48:34.587567	2026-05-24 03:48:34.587567	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
e00a2566-0bff-4eec-bb86-84f1871120ce	Proyecto 02	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 03:48:41.518698	2026-05-24 03:48:41.518698	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
92778fcb-3292-44cb-a51d-af299d23092b	Proyecto 03	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 03:48:49.633184	2026-05-24 03:48:49.633184	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
ea309e84-34bd-47f5-bf2f-ab90c5ea049c	Proyecto 04	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 03:48:59.126615	2026-05-24 03:48:59.126615	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
79a365f6-8e1c-403c-b03c-514df8d23223	Proyecto 05	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 03:49:05.650466	2026-05-24 03:49:05.650466	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
d63619bc-7494-487c-b554-e1dc2a7fae8c	Proyecto 06	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 03:49:10.881622	2026-05-24 03:49:10.881622	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
3ccc314d-3f2c-4686-a309-19c51c7d7e4a	Proyecto 07	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 03:49:16.468933	2026-05-24 03:49:16.468933	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
ebdba837-7f70-43d8-a8b1-ef21eb886520	Proyecto 08	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 03:49:21.266968	2026-05-24 03:49:21.266968	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
2be88f1d-a4df-429e-a865-535ded31ee20	Proyecto 009	Descripción del proyecto creado por el nuevo cliente	Desarrollo Web	3000.00	45	open	2026-05-24 04:20:39.772537	2026-05-24 04:20:39.772537	ea271d6d-c615-4320-83ec-3fe0ea23d1bc	f
\.


--
-- Data for Name: proposals; Type: TABLE DATA; Schema: public; Owner: protask
--

COPY public.proposals (id, "offeredPrice", "estimatedDays", description, status, "createdAt", "updatedAt", "projectId", "freelancerId") FROM stdin;
21915b06-0154-4459-a780-0a2ba7978915	450.00	10	Puedo realizar este proyecto en 10 días. Tengo experiencia en desarrollo web con React y Node.js.	pending	2026-05-19 20:11:01.749416	2026-05-19 20:11:01.749416	ef3bcd39-130c-418e-83f5-7c56cd6aae8f	85690fd3-8842-4357-9d9a-e33b43f58a52
8a085701-ac12-43ad-b54f-81f8ad12b69e	900.00	20	Puedo desarrollar tu tienda online en 20 días. Tengo experiencia con React y Node.js.	pending	2026-05-19 23:58:26.634265	2026-05-19 23:58:26.634265	d53595ea-7974-4e4b-9e07-aa613d64f656	798a17d5-3bb8-41e3-bedb-0fac7da8d603
7ae14b59-ce65-4a7b-8619-8aac498ba2ed	2300.00	40	Propuesta desde freelancer verificado	pending	2026-05-21 21:02:29.449801	2026-05-21 21:02:29.449801	787badac-c162-473a-b516-b2987e871381	5f3917fb-0753-41be-aa3e-e3eda8418990
5e3cf137-0bda-4b50-8bb6-15e5a0de7341	2800.00	40	Tengo experiencia en apps de inventario...	pending	2026-05-21 22:39:31.308161	2026-05-21 22:39:31.308161	44fccee3-f321-4a7b-90b9-8f5631118ac3	19a5686b-a527-4366-a2f7-9849fcb11f7c
999cd876-23e1-41ff-93b4-2167aefecfa4	28300.00	430	Tengo experiencia en apps de inventarioyasy...	pending	2026-05-21 22:47:07.303814	2026-05-21 22:47:07.303814	f8ad0de6-82f2-4a39-a9e8-06887d7a794e	19a5686b-a527-4366-a2f7-9849fcb11f7c
147a905f-0dc6-412b-99ad-b9d57099168c	28300.00	430	Tengo experiencia en apps de inventarioyasy...	pending	2026-05-21 22:48:39.341645	2026-05-21 22:48:39.341645	44fccee3-f321-4a7b-90b9-8f5631118ac3	19a5686b-a527-4366-a2f7-9849fcb11f7c
b3983aff-ca78-494a-b01c-0611b4878809	3800.00	45	Tengo 4 años de experiencia en desarrollo móvil. He trabajado con React Native y Flutter. Puedo entregar antes del plazo.	accepted	2026-05-22 22:18:07.377109	2026-05-22 22:29:15.934086	c3bc3b97-ebfd-4741-869c-09eaf168d7af	5f3917fb-0753-41be-aa3e-e3eda8418990
af1db3aa-7dd1-48b0-a44d-50cf5ba07d8d	1800.00	25	Puedo desarrollar la app de entregas en 25 días con React Native y Node.js	accepted	2026-05-24 01:22:16.140101	2026-05-24 01:25:44.434059	c05cf8be-bada-45ed-bc27-e7687fcba93f	5b81d723-3a98-4315-aed8-4cb2d63ac2c1
5014e373-cd17-4272-a6b5-62b020a2c1ae	1800.00	25	Puedo desarrollar la app de entregas en 25 días con React Native y Node.js	accepted	2026-05-24 01:57:57.544002	2026-05-24 02:00:27.288768	d267cdf8-b859-494e-85d1-c163cc946368	5b81d723-3a98-4315-aed8-4cb2d63ac2c1
0b8542ae-1a04-4895-a0f3-2ed3f11a30cf	1800.00	25	Puedo desarrollar la app de entregas en 25 días con React Native y Node.js	pending	2026-05-24 03:50:00.782953	2026-05-24 03:50:00.782953	ebdba837-7f70-43d8-a8b1-ef21eb886520	5b81d723-3a98-4315-aed8-4cb2d63ac2c1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: protask
--

COPY public.users (id, name, email, password, role, status, phone, bio, "avatarUrl", location, "hourlyRate", skills, rating, "totalReviews", "completedProjects", "isVerified", "verifiedAt", "lastLoginAt", "createdAt", "updatedAt", "portfolioFiles") FROM stdin;
19a5686b-a527-4366-a2f7-9849fcb11f7c	María Fernanda López	maria.fullstack@dev.com	$2b$12$zYn9lwo7U7zHZbKJqdnOputeoNvXuKec.13hL6Y1uC/1LyRtyYJ62	freelancer	activo	\N	\N	\N	\N	\N	\N	0.00	0	0	t	2026-05-21 18:36:47.691	2026-05-21 18:30:39.2	2026-05-21 22:30:17.482943	2026-05-22 02:18:48.095868	\N
ff995b9b-0d0a-4090-bba3-3017af290ac6	Administrador 2	admin2@protask.com	$2b$10$5wJqXqJqXqJqXqJqXqJqXO	administrador	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-21 00:48:51.207	2026-05-21 04:39:01.948929	2026-05-21 04:48:51.221435	\N
60460136-1c2e-4041-bad4-933625da3ade	Empresa Innovatech	empresa_innovatech@negocio.com	$2b$12$i1NnZqtCI5WMrmo/WWgI5.W9G1aO2RJw1sXfEQIPANR.mXSCMEXEO	cliente	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-21 17:15:51.637	2026-05-21 20:45:55.273254	2026-05-21 21:15:51.644286	\N
fb42a0b8-f904-4123-b4c7-cb92266c9522	Cliente Test	cliente@test.com	$2b$12$mLyhyeccFGwP2cF4bTDndeck7s0GxEZzkF14GXyLpzrvcdn64bZay	cliente	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-19 19:57:02.077	2026-05-19 23:31:07.809211	2026-05-19 23:57:02.084143	\N
798a17d5-3bb8-41e3-bedb-0fac7da8d603	Freelancer Test	freelancer@test.com	$2b$12$n9JquUEDIvoeG9swvm4jP.y/WNo3B7jsEJW3yw.tSmPmQwKZF0fmK	freelancer	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-19 19:57:12.438	2026-05-19 23:32:33.767598	2026-05-19 23:57:12.441599	\N
462687d5-0742-4c7b-b69a-627074be1887	Creativa Digital Agency	proyectos@creativadigital.com	$2b$12$QyevOYIIQ/AEt48TQsM1t.UNSbjYDdaZuVzPZ4x03ATZbbm9Ihwti	cliente	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-22 18:09:00.506	2026-05-21 22:28:13.636737	2026-05-22 22:09:00.510178	\N
5b81d723-3a98-4315-aed8-4cb2d63ac2c1	Freelancer Postman	freelancer.postman@test.com	$2b$12$5CFkfsHST80CNgLUV.O4/e1u0h1qCGuOPvbjoGhwqB.pAJPj6BM8e	freelancer	activo	\N	\N	\N	\N	\N	\N	0.00	0	0	t	2026-05-23 20:23:21.605	2026-05-24 00:20:53.622	2026-05-23 23:07:04.285795	2026-05-24 04:20:53.629474	\N
e430cb0e-76e2-4dfe-864e-faaae9c52d55	Freelancer Uno	freelancer1@test.com	$2b$12$3vQaHv2H/fFkp53cyNFh1.4EtT830vmRri3RCL6OxBydS80PAehey	freelancer	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	\N	2026-05-19 19:31:15.981745	2026-05-21 16:35:22.340512	\N
96f123c0-285e-449b-be59-49c695dab4a7	Cliente Real	cliente_real@test.com	$2b$12$YMigrJSTHiFm.IBI3nuPQep7rUSHSbwhsuOuf04uPvpkK.MxDAg8q	cliente	pendiente_verificacion	\N	\N	\N	\N	\N	JavaScript,React,Node.js,TypeScript	0.00	0	0	f	\N	\N	2026-05-19 19:56:01.904962	2026-05-21 16:40:16.197827	\N
85690fd3-8842-4357-9d9a-e33b43f58a52	Freelancer dos	freelancer2@test.com	$2b$12$j1emIaxXXXGrwLHkDTj45e3JE8fN1QkGMH47PcIaf9MbXpogd7aEu	freelancer	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	\N	2026-05-19 20:08:28.937631	2026-05-21 16:44:03.604175	\N
ae1e5b28-a0fe-4d8f-b7e1-04088278b44a	Freelancer Test	freelancer5@test.com	$2b$12$1YQY8TORpEwoL9mxZ6poo.EaODOQHGW4hd7b95wrXXZFSLuSBpFki	freelancer	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-21 01:45:00.642	2026-05-21 05:17:21.080456	2026-05-21 05:45:00.654689	\N
e1c5a8f1-fa26-4696-b8c4-5b2c38606ce6	SsFreelancer Test	Ssfreelancer@test.com	$2b$12$TBisK77I8SNfkPdzqnj4deqlqGfcR6it9/7C9ialoc3TB2eeBgTDS	freelancer	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-21 11:21:34.543	2026-05-21 15:19:35.992562	2026-05-21 15:21:34.548855	\N
5f3917fb-0753-41be-aa3e-e3eda8418990	Laura Gómez	laura_diseno@freelance.com	$2b$12$NfWCukxfMH3g3Spz43wX1OrXoAn9u5EstKvF1j8IdDh3g9/XI8yf6	freelancer	activo	\N	\N	\N	\N	\N	\N	0.00	0	0	t	2026-05-21 16:41:49.042	2026-05-22 18:10:55.283	2026-05-21 20:03:54.087725	2026-05-22 22:10:55.287769	\N
f690a9ed-f5a7-4ae1-bfb6-31b13e227284	Juan Pérez	juan@ejemplo.com	$2b$12$6/CTk6yPwAEDT0hdG85gK.0G1ZNxOY6HqrLEik7o/JePtc5i6RiLG	cliente	pendiente_verificacion	\N	\N	\N	\N	\N	JavaScript,React,Node.js	0.00	0	0	f	\N	\N	2026-05-17 22:54:09.316838	2026-05-21 15:34:19.543373	\N
677d00fa-697a-47da-99ae-20cd2782ec02	FreelancerNNNN	freelancerNNNN@test.com	$2b$12$Plt25.SLGsd9PXJEJXowguIfEstKN7EvhqjltJCS3BSz6UvoN5dta	freelancer	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-21 15:46:58.845	2026-05-21 18:32:57.119031	2026-05-21 19:46:58.848665	\N
0206cdab-00c9-47b5-a041-cc7f0dc6d690	Cliente Nuevo	cliente_nuevo@test.com	$2b$12$RD8rCwdP7cNuzua0vkCJXugYsy7FcakD2TZA1azMzhd22.UfO7vLS	cliente	pendiente_verificacion	\N	\N	\N	\N	\N	JavaScript,React,Node.js,TypeScript	0.00	0	0	f	\N	\N	2026-05-19 16:06:05.915425	2026-05-21 16:07:43.449223	\N
162d61f3-5c0a-4c37-8b53-4cc4d024e69f	Freelancer Perfil	freelancerperfil@test.com	$2b$12$xVuSiwzBXR45irIVQs/8pOh1icG73ueJz7pMqMdyTWhJekGLbmPJ2	freelancer	pendiente_verificacion	\N	\N	\N	\N	\N	["JavaScript","React","Node.js"]	0.00	0	0	f	\N	2026-05-21 14:17:09.324	2026-05-21 15:24:28.644974	2026-05-21 18:17:09.328612	\N
59d03a47-4f9e-4b35-985c-5101b4c4ebda	LLaura Gómez	LLLaura_diseno@freelance.com	$2b$12$3B5834EKvvaMLI9/JF1wN.lrR/ZfuUeibIw7MkMq3O5Oaa/WQoN.K	freelancer	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-21 16:10:15.087	2026-05-21 20:06:35.373311	2026-05-21 20:10:15.091487	\N
3d36bad7-5998-4d98-9717-82d3f3ca5985	Freelancer KYC	freelancerkyc@test.com	$2b$10$5wJqXqJqXqJqXqJqXqJqXO	freelancer	activo	\N	\N	\N	\N	\N	\N	0.00	0	0	t	2026-05-21 00:51:14.014	\N	2026-05-21 04:29:11.246244	2026-05-21 04:51:14.020342	\N
ca80d7f7-43ab-48e1-8030-9cc49f1ba63e	Cliente Proyecto	cliente_proyecto@test.com	$2b$12$Cj5eUoexoeEMLFuh2q1re.2izrUmUbIYNJ3XLPJj7f466a/jWvoV.	cliente	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-21 14:27:50.593	2026-05-21 18:05:08.108022	2026-05-21 18:27:50.595504	\N
c3107984-892e-4656-85d2-53adf4c36d84	Cliente Fuerte	cliente.fuerte@test.com	$2b$12$C/7tmgnjRKB8T49E01HV.OppFAJsVM0Cg.gQbNWN64z8KxoU.WfpS	cliente	activo	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-23 18:13:30.218	2026-05-23 20:53:04.476721	2026-05-23 22:13:30.223522	\N
2ee88ddf-1da7-48c1-8a7a-c33d0c6c8f4d	Empresa Nueva SA	empresa_nueva@test.com	$2b$12$QAcLTnu0cuvivF9pGeH3Iu0ut.1F0eXT0bCbp73E01w9e/fOaCiR2	cliente	pendiente_verificacion	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-22 18:14:22.033	2026-05-22 22:12:40.792296	2026-05-22 22:14:22.035157	\N
a3e68181-2668-4b2a-b5ba-9606e9587405	Cliente Prueba	cliente.prueba@test.com	$2b$12$ir1iPoht7CIr1TAKpFiGZOpNUR0hBwhfe/k2s6EaWoS9MwatF8LVq	cliente	activo	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-23 20:59:19.029	2026-05-23 22:10:03.530158	2026-05-24 00:59:19.03594	\N
690d9515-9ab3-479b-b5e5-eccb9d240615	Freelancer Prueba	freelancer.prueba@test.com	$2b$12$8kqNHxM6DQa/.NytiaYSMO/ZACFpvdk3M0Bz7zt7FzXY0X7UhceD.	freelancer	activo	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-23 18:42:17.387	2026-05-23 22:12:19.934919	2026-05-23 22:42:17.41643	\N
5242a885-1ba7-416b-8b4a-2a11667e45d3	Administrador ProTask	admin@protask.com	$2b$10$rRR5xdEjMo01dIRPOxLbH.MoEiaGBUsIjXT6O6rWP/aNd/fTR0fg2	administrador	activo	\N	\N	\N	\N	\N	\N	0.00	0	0	t	\N	2026-05-23 20:21:46.694	2026-05-21 19:02:15.461708	2026-05-24 00:21:46.704841	\N
ea271d6d-c615-4320-83ec-3fe0ea23d1bc	Cliente Nuevo	cliente.nuevo@test.com	$2b$12$sZI5Jn.HIPyNl.szqZpTt.qXveVQOYsrK7irMIF9T6INyczfTRxtW	cliente	activo	\N	\N	\N	\N	\N	\N	0.00	0	0	f	\N	2026-05-23 21:14:18.681	2026-05-24 01:13:53.806788	2026-05-24 01:14:18.686924	\N
\.


--
-- Name: escrow_deposits PK_1538f7b6f6cc5623c9129441e33; Type: CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.escrow_deposits
    ADD CONSTRAINT "PK_1538f7b6f6cc5623c9129441e33" PRIMARY KEY (id);


--
-- Name: projects PK_6271df0a7aed1d6c0691ce6ac50; Type: CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "PK_6271df0a7aed1d6c0691ce6ac50" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: proposals PK_db524c8db8e126a38a2f16d8cac; Type: CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT "PK_db524c8db8e126a38a2f16d8cac" PRIMARY KEY (id);


--
-- Name: kyc_verificaciones PK_eaa710372933152ca0a12854e78; Type: CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.kyc_verificaciones
    ADD CONSTRAINT "PK_eaa710372933152ca0a12854e78" PRIMARY KEY (id);


--
-- Name: escrow_deposits REL_ddad5f0e01693ff4423cb40eb0; Type: CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.escrow_deposits
    ADD CONSTRAINT "REL_ddad5f0e01693ff4423cb40eb0" UNIQUE ("proposalId");


--
-- Name: users UQ_97672ac88f789774dd47f7c8be3; Type: CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "UQ_97672ac88f789774dd47f7c8be3" UNIQUE (email);


--
-- Name: IDX_091f9433895a53408cb8ae3864; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_091f9433895a53408cb8ae3864" ON public.projects USING btree ("clientId");


--
-- Name: IDX_09d2319018bf917d600ba742c5; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_09d2319018bf917d600ba742c5" ON public.proposals USING btree (status);


--
-- Name: IDX_219edc10f7e4cc15dd19ea5d36; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_219edc10f7e4cc15dd19ea5d36" ON public.proposals USING btree ("freelancerId");


--
-- Name: IDX_22611978869ac4a34bd7a97fc1; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_22611978869ac4a34bd7a97fc1" ON public.projects USING btree (category);


--
-- Name: IDX_3676155292d72c67cd4e090514; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_3676155292d72c67cd4e090514" ON public.users USING btree (status);


--
-- Name: IDX_4a38e9851744414bbe8142157f; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_4a38e9851744414bbe8142157f" ON public.projects USING btree ("createdAt");


--
-- Name: IDX_67e7c08d2db3b060496c1e8fe2; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_67e7c08d2db3b060496c1e8fe2" ON public.escrow_deposits USING btree ("freelancerId");


--
-- Name: IDX_97672ac88f789774dd47f7c8be; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_97672ac88f789774dd47f7c8be" ON public.users USING btree (email);


--
-- Name: IDX_a27865a7be17886e3088f4a650; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_a27865a7be17886e3088f4a650" ON public.projects USING btree (status);


--
-- Name: IDX_ace513fa30d485cfd25c11a9e4; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_ace513fa30d485cfd25c11a9e4" ON public.users USING btree (role);


--
-- Name: IDX_b676cd0c373460f13042e18dc8; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_b676cd0c373460f13042e18dc8" ON public.escrow_deposits USING btree ("clienteId");


--
-- Name: IDX_d9184f05fdd28bd7c960d9a7e4; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_d9184f05fdd28bd7c960d9a7e4" ON public.proposals USING btree ("projectId");


--
-- Name: IDX_ddad5f0e01693ff4423cb40eb0; Type: INDEX; Schema: public; Owner: protask
--

CREATE UNIQUE INDEX "IDX_ddad5f0e01693ff4423cb40eb0" ON public.escrow_deposits USING btree ("proposalId");


--
-- Name: IDX_ebfff6b2ecb379f895e2d2e4c1; Type: INDEX; Schema: public; Owner: protask
--

CREATE UNIQUE INDEX "IDX_ebfff6b2ecb379f895e2d2e4c1" ON public.kyc_verificaciones USING btree ("userId");


--
-- Name: IDX_f3575c613f89377aa9b3638c34; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_f3575c613f89377aa9b3638c34" ON public.escrow_deposits USING btree (estado);


--
-- Name: IDX_fe71cba98284d39163a45bf581; Type: INDEX; Schema: public; Owner: protask
--

CREATE INDEX "IDX_fe71cba98284d39163a45bf581" ON public.kyc_verificaciones USING btree (status);


--
-- Name: projects FK_091f9433895a53408cb8ae3864f; Type: FK CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "FK_091f9433895a53408cb8ae3864f" FOREIGN KEY ("clientId") REFERENCES public.users(id);


--
-- Name: proposals FK_219edc10f7e4cc15dd19ea5d36d; Type: FK CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT "FK_219edc10f7e4cc15dd19ea5d36d" FOREIGN KEY ("freelancerId") REFERENCES public.users(id);


--
-- Name: escrow_deposits FK_67e7c08d2db3b060496c1e8fe25; Type: FK CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.escrow_deposits
    ADD CONSTRAINT "FK_67e7c08d2db3b060496c1e8fe25" FOREIGN KEY ("freelancerId") REFERENCES public.users(id);


--
-- Name: escrow_deposits FK_b676cd0c373460f13042e18dc8d; Type: FK CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.escrow_deposits
    ADD CONSTRAINT "FK_b676cd0c373460f13042e18dc8d" FOREIGN KEY ("clienteId") REFERENCES public.users(id);


--
-- Name: proposals FK_d9184f05fdd28bd7c960d9a7e40; Type: FK CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.proposals
    ADD CONSTRAINT "FK_d9184f05fdd28bd7c960d9a7e40" FOREIGN KEY ("projectId") REFERENCES public.projects(id);


--
-- Name: escrow_deposits FK_ddad5f0e01693ff4423cb40eb08; Type: FK CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.escrow_deposits
    ADD CONSTRAINT "FK_ddad5f0e01693ff4423cb40eb08" FOREIGN KEY ("proposalId") REFERENCES public.proposals(id);


--
-- Name: kyc_verificaciones FK_ebfff6b2ecb379f895e2d2e4c19; Type: FK CONSTRAINT; Schema: public; Owner: protask
--

ALTER TABLE ONLY public.kyc_verificaciones
    ADD CONSTRAINT "FK_ebfff6b2ecb379f895e2d2e4c19" FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict p5lVd5ZCJYOxT7ziLUNKrNNXCEkq0zK7ubJxmKe3Ddz47q9k76gQJ6DzaeW9Zfg

